How to install Microsoft sql server (mssql server) on Ec2 instance 

1. Launch Ec2 instance with windows OS (windows 2016 server) on public subnet 
2. Install RDP client if you are on MAC
   https://learn.microsoft.com/en-us/sql/ssms/download-sql-server-management-studio-ssms?view=sql-server-ver16
4. Login to windows ec2 instance using rdp
5. Download sqlserv developer version using edge brower 
  https://www.microsoft.com/en-us/sql-server/sql-server-downloads
  
  Click install ==> select basic
